-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.6.25-0ubuntu0.15.04.1 - (Ubuntu)
-- SO del servidor:              debian-linux-gnu
-- HeidiSQL Versión:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura de base de datos para socialnetwork
CREATE DATABASE IF NOT EXISTS `socialnetwork` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `socialnetwork`;


-- Volcando estructura para tabla socialnetwork.Post
CREATE TABLE IF NOT EXISTS `Post` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `datatype` int(11) NOT NULL,
  `content` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`user_id`),
  CONSTRAINT `userid` FOREIGN KEY (`user_id`) REFERENCES `User` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla socialnetwork.Post: ~0 rows (aproximadamente)
DELETE FROM `Post`;
/*!40000 ALTER TABLE `Post` DISABLE KEYS */;
/*!40000 ALTER TABLE `Post` ENABLE KEYS */;


-- Volcando estructura para tabla socialnetwork.User
CREATE TABLE IF NOT EXISTS `User` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` char(50) NOT NULL,
  `password` char(50) NOT NULL,
  `full_name` char(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='utf8_general_ci';

-- Volcando datos para la tabla socialnetwork.User: ~5 rows (aproximadamente)
DELETE FROM `User`;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` (`id`, `email`, `password`, `full_name`) VALUES
	(1, 'la@llama.com', 'llama', 'La llama'),
	(2, 'el@ernesto.com', 'elernes', 'Ernesto'),
	(3, 'pepe21@correogratis.com', 'lamorza', 'Pepe Argento'),
	(4, 'alberto@hotmail.com', 'chiche', 'Alberto'),
	(5, 'alberto@gmail.com', 'alberto123', 'Alberto');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;


-- Volcando estructura para tabla socialnetwork.User_session
CREATE TABLE IF NOT EXISTS `User_session` (
  `id` char(40) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `User` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='utf8_general_ci';

-- Volcando datos para la tabla socialnetwork.User_session: ~2 rows (aproximadamente)
DELETE FROM `User_session`;
/*!40000 ALTER TABLE `User_session` DISABLE KEYS */;
INSERT INTO `User_session` (`id`, `user_id`) VALUES
	('7e2a4337-7e09-47ce-a387-6ce7215a049e', 1),
	('acf6d2ed-fa93-4665-8d93-d4ec49db939e', 5);
/*!40000 ALTER TABLE `User_session` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;

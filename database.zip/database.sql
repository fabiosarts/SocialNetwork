-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.26-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.3.0.4988
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for socialnetwork
CREATE DATABASE IF NOT EXISTS `socialnetwork` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `socialnetwork`;


-- Dumping structure for table socialnetwork.comment
CREATE TABLE IF NOT EXISTS `comment` (
  `comment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `content` varchar(250) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`),
  KEY `FK_comment_post` (`post_id`),
  KEY `FK_comment_user` (`user_id`),
  CONSTRAINT `FK_comment_post` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE NO ACTION,
  CONSTRAINT `FK_comment_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Dumping data for table socialnetwork.comment: ~5 rows (approximately)
DELETE FROM `comment`;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` (`comment_id`, `user_id`, `post_id`, `content`, `timestamp`) VALUES
	(1, 1, 2, 'Ola k ase!', '2015-05-21 17:26:28'),
	(2, 3, 2, 'Moni ya me tiene arto!', '2015-06-24 19:26:28'),
	(3, 4, 3, ':3', '2015-07-21 22:26:28'),
	(4, 3, 8, 'Esto es un comentario para la base de datos :B', '2015-07-20 12:48:01'),
	(5, 1, 8, 'Este es un segundo comentario :3', '2015-08-26 02:26:28'),
	(6, 1, 8, 'Esto debería salir primero :D', '2015-09-20 02:30:34'),
	(7, 4, 7, 'Primer comentario', '2015-09-20 12:47:24'),
	(8, 2, 7, 'Segundo comentario', '2015-09-20 12:46:43'),
	(9, 1, 7, 'Probando el botón submit', '2015-09-20 02:34:19'),
	(10, 1, 6, 'si', '2015-09-20 02:52:30'),
	(11, 1, 10, 'me esta imitando o k ase?', '2015-09-20 19:05:11'),
	(12, 1, 3, 'Esto es un comentario', '2015-09-20 21:31:22'),
	(13, 1, 10, 'comentario', '2015-09-21 16:58:55');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;


-- Dumping structure for table socialnetwork.post
CREATE TABLE IF NOT EXISTS `post` (
  `post_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `datatype` int(11) NOT NULL,
  `content` varchar(250) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`post_id`),
  KEY `userid` (`user_id`),
  CONSTRAINT `author_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table socialnetwork.post: ~8 rows (approximately)
DELETE FROM `post`;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`post_id`, `user_id`, `datatype`, `content`, `timestamp`) VALUES
	(1, 4, 0, 'Esto es un comentario de prueba', '2015-03-19 12:00:00'),
	(2, 2, 0, 'Este es otro comentario', '2015-05-19 15:40:00'),
	(3, 3, 0, 'Me cago un dinosaurio', '2015-09-19 16:05:00'),
	(6, 1, 0, 'Esto funciona?', '1969-12-31 21:00:00'),
	(7, 1, 0, 'Sirve la fecha actual?', '2015-09-20 01:29:36'),
	(8, 1, 0, '123', '2015-09-20 01:36:16'),
	(10, 4, 0, 'Ola k ase llama!', '2015-09-20 19:04:32');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;


-- Dumping structure for table socialnetwork.relationship
CREATE TABLE IF NOT EXISTS `relationship` (
  `relation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_a` bigint(20) DEFAULT NULL,
  `user_b` bigint(20) DEFAULT NULL,
  `relation_type` int(11) NOT NULL,
  PRIMARY KEY (`relation_id`),
  KEY `FK_relationship_user` (`user_a`),
  KEY `FK_relationship_user_2` (`user_b`),
  CONSTRAINT `FK_relationship_user` FOREIGN KEY (`user_a`) REFERENCES `user` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `FK_relationship_user_2` FOREIGN KEY (`user_b`) REFERENCES `user` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- Dumping data for table socialnetwork.relationship: ~2 rows (approximately)
DELETE FROM `relationship`;
/*!40000 ALTER TABLE `relationship` DISABLE KEYS */;
INSERT INTO `relationship` (`relation_id`, `user_a`, `user_b`, `relation_type`) VALUES
	(8, 1, 4, 2),
	(9, 3, 1, 2),
	(11, 2, 1, 1);
/*!40000 ALTER TABLE `relationship` ENABLE KEYS */;


-- Dumping structure for table socialnetwork.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` char(50) NOT NULL,
  `password` char(50) NOT NULL,
  `full_name` char(100) NOT NULL,
  `status` char(150) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='utf8_general_ci';

-- Dumping data for table socialnetwork.user: ~4 rows (approximately)
DELETE FROM `user`;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`, `email`, `password`, `full_name`, `status`) VALUES
	(1, 'le@llama.com', 'llama', 'Le llama', 'Ola k ase!!'),
	(2, 'el@ernesto.com', 'elernes', 'Ernesto', 'Los DVDs están 10$'),
	(3, 'pepe21@correogratis.com', 'lamorza', 'Pepe Argento', 'Me gusta el nuevo BluRay que tenía dardo, lástima que no lo puedo usar .'),
	(4, 'alberto@hotmail.com', 'chiche', 'Alberto', 'Nope');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


-- Dumping structure for table socialnetwork.user_session
CREATE TABLE IF NOT EXISTS `user_session` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `user_fk` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='utf8_general_ci';

-- Dumping data for table socialnetwork.user_session: ~15 rows (approximately)
DELETE FROM `user_session`;
/*!40000 ALTER TABLE `user_session` DISABLE KEYS */;
INSERT INTO `user_session` (`session_id`, `user_id`) VALUES
	(21, 1),
	(22, 1),
	(23, 1),
	(24, 1),
	(25, 1),
	(26, 1),
	(27, 1),
	(28, 1),
	(29, 1),
	(30, 1),
	(31, 1),
	(32, 1),
	(34, 1),
	(35, 1),
	(33, 4);
/*!40000 ALTER TABLE `user_session` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
